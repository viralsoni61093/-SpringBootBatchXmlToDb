package com.batch.config;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.batch.item.database.ItemPreparedStatementSetter;

import com.batch.model.exchange;
import com.batch.model.idc_calendar;

public class ExchangePreparedStatementSetter implements ItemPreparedStatementSetter<exchange> {

	@Override
	public void setValues(exchange exchange, PreparedStatement ps) throws SQLException {

			
					ps.setString(1,  exchange.keys.getKey().get(0).getXref_code());
					
					ps.setString(2, exchange.getExchange_description());
					
					ps.setString(3, exchange.getDescriptive_data().getTrading_info().getTrading_sessions().getSession_hours()
							.getMonday().getSession_start());
					
					ps.setString(4, exchange.getDescriptive_data().getTrading_info().getTrading_sessions().getSession_hours()
							.getMonday().getSession_end());
					
					ps.setString(5, exchange.getDescriptive_data().getTimezone_info().getTz_long_name());
					
					ps.setLong(6, exchange.getDescriptive_data().getTimezone_info().getTz_has_dst());
					
					ps.setString(7, exchange.getDescriptive_data().getTimezone_info().getTz_offset().get(0).getOffset_sign());
					
					ps.setString(8, exchange.getDescriptive_data().getTimezone_info().getTz_offset().get(0).getOffset());
					
					ps.setString(9,
							exchange.getDescriptive_data().getTimezone_info().getTz_offset().get(0).getOlson_short_name());
					
					ps.setString(10, exchange.getTrading_day_data().getExchange_hours().getOpen_utc());
					
					ps.setString(11, exchange.getTrading_day_data().getExchange_hours().getOpen_utc());
					
//
//			ps.setInt(12, market_info.getIntro_change_id());
//			ps.setInt(12, market_info.getIntro_change_id());
					
//			ps.setInt(13,market_info.getEnd_change_id());
//			ps.setInt(13,market_info.getEnd_change_id());
					

	}
//	public class ExchangePreparedStatementSetter implements ItemPreparedStatementSetter<idc_calendar> {
//		
//		@Override
//		public void setValues(idc_calendar idc_calendar, PreparedStatement ps) throws SQLException {
//			
//			List<exchange> exchangeList = idc_calendar.getExchange_data().getExchange();
//			exchangeList.forEach(exchange -> {
//				try {
//					ps.setString(1,  exchange.keys.getKey().get(0).getXref_code());
//					
//					ps.setString(2, exchange.getExchange_description());
//					
//					ps.setString(3, exchange.getDescriptive_data().getTrading_info().getTrading_sessions().getSession_hours()
//							.getMonday().getSession_start());
//					
//					ps.setString(4, exchange.getDescriptive_data().getTrading_info().getTrading_sessions().getSession_hours()
//							.getMonday().getSession_end());
//					
//					ps.setString(5, exchange.getDescriptive_data().getTimezone_info().getTz_long_name());
//					
//					ps.setLong(6, exchange.getDescriptive_data().getTimezone_info().getTz_has_dst());
//					
//					ps.setString(7, exchange.getDescriptive_data().getTimezone_info().getTz_offset().get(0).getOffset_sign());
//					
//					ps.setString(8, exchange.getDescriptive_data().getTimezone_info().getTz_offset().get(0).getOffset());
//					
//					ps.setString(9,
//							exchange.getDescriptive_data().getTimezone_info().getTz_offset().get(0).getOlson_short_name());
//					
//					ps.setString(10, exchange.getTrading_day_data().getExchange_hours().getOpen_utc());
//					
//					ps.setString(11, exchange.getTrading_day_data().getExchange_hours().getOpen_utc());
//					
////
////			ps.setInt(12, market_info.getIntro_change_id());
////			ps.setInt(12, market_info.getIntro_change_id());
//					
////			ps.setInt(13,market_info.getEnd_change_id());
////			ps.setInt(13,market_info.getEnd_change_id());
//					
//					
//				} catch (SQLException e) {
//					e.printStackTrace();
//				}
//			});
//		}

}
