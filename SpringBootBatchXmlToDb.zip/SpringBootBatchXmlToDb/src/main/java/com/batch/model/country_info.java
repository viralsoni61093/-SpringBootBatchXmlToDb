package com.batch.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("country_info")
public class country_info { 
	public String getIso_alpha2_code() {
		return iso_alpha2_code;
	}
	public void setIso_alpha2_code(String iso_alpha2_code) {
		this.iso_alpha2_code = iso_alpha2_code;
	}
	public String getIso_country_name() {
		return iso_country_name;
	}
	public void setIso_country_name(String iso_country_name) {
		this.iso_country_name = iso_country_name;
	}
	public String iso_alpha2_code;
	public String iso_country_name;
}
