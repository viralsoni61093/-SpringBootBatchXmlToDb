package com.batch.model;

import java.util.Date;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Monday")
public class Monday { 
	public int session_open;
	public String session_start;
	public int getSession_open() {
		return session_open;
	}
	public void setSession_open(int session_open) {
		this.session_open = session_open;
	}
	public String getSession_start() {
		return session_start;
	}
	public void setSession_start(String session_start) {
		this.session_start = session_start;
	}
	public String getSession_end() {
		return session_end;
	}
	public void setSession_end(String session_end) {
		this.session_end = session_end;
	}
	public String session_end;
}
