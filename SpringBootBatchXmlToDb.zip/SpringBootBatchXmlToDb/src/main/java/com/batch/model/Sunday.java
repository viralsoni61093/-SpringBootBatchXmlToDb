package com.batch.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Sunday")
public class Sunday { 
	public int session_open;

	public int getSession_open() {
		return session_open;
	}

	public void setSession_open(int session_open) {
		this.session_open = session_open;
	}
}
