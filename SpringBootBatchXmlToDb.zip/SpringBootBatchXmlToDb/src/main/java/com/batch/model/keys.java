package com.batch.model;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("keys")
public class keys { 
	public List<key> getKey() {
		return key;
	}

	public void setKey(List<key> key) {
		this.key = key;
	}

	@XStreamImplicit(itemFieldName = "key")
	public List<key> key;
}
