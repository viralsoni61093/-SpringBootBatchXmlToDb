package com.batch.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("support_info")
public class support_info { 
	public String support_group;

	public String getSupport_group() {
		return support_group;
	}

	public void setSupport_group(String support_group) {
		this.support_group = support_group;
	}
}
