package com.batch.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("session_hours")
public class session_hours { 
	public Sunday Sunday;
	public Monday Monday;
	public Tuesday Tuesday;
	public Wednesday Wednesday;
	public Thursday Thursday;
	public Friday Friday;
	public Saturday Saturday;
	public Sunday getSunday() {
		return Sunday;
	}
	public void setSunday(Sunday sunday) {
		Sunday = sunday;
	}
	public Monday getMonday() {
		return Monday;
	}
	public void setMonday(Monday monday) {
		Monday = monday;
	}
	public Tuesday getTuesday() {
		return Tuesday;
	}
	public void setTuesday(Tuesday tuesday) {
		Tuesday = tuesday;
	}
	public Wednesday getWednesday() {
		return Wednesday;
	}
	public void setWednesday(Wednesday wednesday) {
		Wednesday = wednesday;
	}
	public Thursday getThursday() {
		return Thursday;
	}
	public void setThursday(Thursday thursday) {
		Thursday = thursday;
	}
	public Friday getFriday() {
		return Friday;
	}
	public void setFriday(Friday friday) {
		Friday = friday;
	}
	public Saturday getSaturday() {
		return Saturday;
	}
	public void setSaturday(Saturday saturday) {
		Saturday = saturday;
	}
}
