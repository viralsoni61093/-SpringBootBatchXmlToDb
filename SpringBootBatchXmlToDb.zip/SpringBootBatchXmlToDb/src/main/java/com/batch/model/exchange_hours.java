package com.batch.model;

import java.util.Date;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("exchange_hours")
public class exchange_hours { 
	public List<Integer> session_id;
	public List<String> session_type;
	public String open_local;
	public String close_local;
	public String olson_short_name;
	public String open_utc;
	public String close_utc;
	public List<Integer> getSession_id() {
		return session_id;
	}
	public void setSession_id(List<Integer> session_id) {
		this.session_id = session_id;
	}
	public List<String> getSession_type() {
		return session_type;
	}
	public void setSession_type(List<String> session_type) {
		this.session_type = session_type;
	}
	public String getOpen_local() {
		return open_local;
	}
	public void setOpen_local(String open_local) {
		this.open_local = open_local;
	}
	public String getClose_local() {
		return close_local;
	}
	public void setClose_local(String close_local) {
		this.close_local = close_local;
	}
	public String getOlson_short_name() {
		return olson_short_name;
	}
	public void setOlson_short_name(String olson_short_name) {
		this.olson_short_name = olson_short_name;
	}
	public String getOpen_utc() {
		return open_utc;
	}
	public void setOpen_utc(String open_utc) {
		this.open_utc = open_utc;
	}
	public String getClose_utc() {
		return close_utc;
	}
	public void setClose_utc(String close_utc) {
		this.close_utc = close_utc;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String text;
}
