package com.batch.model;

import java.util.Date;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("trading_day_data")
public class trading_day_data { 
	public List<String> date_local;
	public String day_of_week_local;
	public exchange_status exchange_status;
	public exchange_hours exchange_hours;
	public String status_detail;
	public String text;
	public List<String> getDate_local() {
		return date_local;
	}
	public void setDate_local(List<String> date_local) {
		this.date_local = date_local;
	}
	public String getDay_of_week_local() {
		return day_of_week_local;
	}
	public void setDay_of_week_local(String day_of_week_local) {
		this.day_of_week_local = day_of_week_local;
	}
	public exchange_status getExchange_status() {
		return exchange_status;
	}
	public void setExchange_status(exchange_status exchange_status) {
		this.exchange_status = exchange_status;
	}
	public exchange_hours getExchange_hours() {
		return exchange_hours;
	}
	public void setExchange_hours(exchange_hours exchange_hours) {
		this.exchange_hours = exchange_hours;
	}
	public String getStatus_detail() {
		return status_detail;
	}
	public void setStatus_detail(String status_detail) {
		this.status_detail = status_detail;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
}
