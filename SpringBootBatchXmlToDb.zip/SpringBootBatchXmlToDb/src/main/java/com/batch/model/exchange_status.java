package com.batch.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("exchange_status")
public class exchange_status { 
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public status_detail getStatus_detail() {
		return status_detail;
	}
	public void setStatus_detail(status_detail status_detail) {
		this.status_detail = status_detail;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String status;
	public status_detail status_detail;
	public String description;
}
