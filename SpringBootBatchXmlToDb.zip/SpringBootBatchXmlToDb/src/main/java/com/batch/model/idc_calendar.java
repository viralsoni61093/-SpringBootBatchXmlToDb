package com.batch.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("idc_calendar")
public class idc_calendar { 
	
	public file_generation getFile_generation() {
		return file_generation;
	}
	public void setFile_generation(file_generation file_generation) {
		this.file_generation = file_generation;
	}
	public exchange_data getExchange_data() {
		return exchange_data;
	}
	public void setExchange_data(exchange_data exchange_data) {
		this.exchange_data = exchange_data;
	}
	public String getXsi() {
		return xsi;
	}
	public void setXsi(String xsi) {
		this.xsi = xsi;
	}
	public String getNoNamespaceSchemaLocation() {
		return noNamespaceSchemaLocation;
	}
	public void setNoNamespaceSchemaLocation(String noNamespaceSchemaLocation) {
		this.noNamespaceSchemaLocation = noNamespaceSchemaLocation;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public file_generation file_generation;
	public exchange_data exchange_data;
	public String xsi;
	public String noNamespaceSchemaLocation;
	public String text;
}
