package com.batch.model;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("trading_sessions")
public class trading_sessions { 
	public List<Integer> session_id;
	public List<String> session_description;
	public String session_type;
	public session_hours session_hours;
	public String text;
	public List<Integer> getSession_id() {
		return session_id;
	}
	public void setSession_id(List<Integer> session_id) {
		this.session_id = session_id;
	}
	public List<String> getSession_description() {
		return session_description;
	}
	public void setSession_description(List<String> session_description) {
		this.session_description = session_description;
	}
	public String getSession_type() {
		return session_type;
	}
	public void setSession_type(String session_type) {
		this.session_type = session_type;
	}
	public session_hours getSession_hours() {
		return session_hours;
	}
	public void setSession_hours(session_hours session_hours) {
		this.session_hours = session_hours;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
}
